/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package driver;

import java.util.Scanner;

/**
 *
 * @author w88m956
 */
public class Driver {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        List paper = new List("Alpha");
        paper.addback("Bravo");
        paper.addback("Charlie");
        paper.addback("Delta");
        paper.addback("Echo");
        
        //paper.delete("Charlie");
        
        
        
        int x = 0;
        while(x!=-1){
        System.out.println("What would you like to do?");
        System.out.println("Press 1 to add an item to the back of the list");
        System.out.println("Press 2 to print the list");
        System.out.println("Press 3 to delete an item");
        System.out.println("Press 4 to clear the whole list");
        System.out.println("Press -1 to exit");
        x = scan.nextInt();
        if(x ==1){
            System.out.println("Please enter the name you would like to add");
            String w = scan.next();     
            paper.addback(w);
        }
        else if (x==2){
            paper.print();
        }
        else if (x==3){
            System.out.println("Please enter the name you would like to delete");
            String w = scan.next();     
            paper.delete(w);
        }
        else if (x == 4){
            paper.a = null;
        }
        }
            System.out.println("Goodbye");
        
        
    }
    
}
