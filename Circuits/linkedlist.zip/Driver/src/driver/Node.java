/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package driver;

/**
 *
 * @author w88m956
 */
public class Node {
    private String name;
    private Node next = null;
    private Node back = null;
    
    Node(String w){
        name = w;
    }
    
    Node(){
        name = "Bob";
    }
    
    void setNext(Node a){
        next = a;
    }
    
    void setBack(Node w){
        back = w;
    }
    
    Node getBack(){
        return(back);
    }
    
    Node getNext(){
        return(next);
    }
    
    void print(){
        System.out.println(name);
    }
    
    String getName(){
        return(name);
    }
    
}
