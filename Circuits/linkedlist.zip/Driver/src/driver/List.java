/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package driver;

/**
 *
 * @author w88m956
 */
public class List {
    Node a;
    
    List(String w){
        a = new Node(w);
    }
    
    void addback(String w){
        Node iter = a;
        while(iter.getNext() != null){
            iter = iter.getNext();
        }
        iter.setNext(new Node(w));
    }
    
    void print(){
        Node iter = a;
        
        do{
            iter.print();
            iter = iter.getNext();
        }
        while(iter != null);
            
         
    }
    
    void delete(String w){
        Node iter = a;
        Node back = a.getBack();
        
        while(iter != null){
            if(iter.getName() == w){
                back.setNext(iter.getNext());
              
            }
            back = iter;
            iter = iter.getNext();
            
            
        }
            
        
     
    }
}
